<?php

return array (
  'next' => '',
  'previous' => '',
);
