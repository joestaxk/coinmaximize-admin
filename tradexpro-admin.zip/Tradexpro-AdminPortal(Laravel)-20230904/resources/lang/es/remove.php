<?php

return array (
  'from' => 
  array (
    'favorite' => '',
  ),
);
