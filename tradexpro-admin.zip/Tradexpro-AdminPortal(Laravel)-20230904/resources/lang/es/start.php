<?php

return array (
  'time' => 
  array (
    'is' => 
    array (
      'always' => 
      array (
        'big' => 
        array (
          'than' => 
          array (
            'end' => 
            array (
              'time' => '',
            ),
          ),
        ),
      ),
    ),
  ),
);
