<?php

return array (
  'to' => 
  array (
    'add' => 
    array (
      'remove' => 
      array (
        'from' => 
        array (
          'favorite' => '',
        ),
      ),
    ),
  ),
);
