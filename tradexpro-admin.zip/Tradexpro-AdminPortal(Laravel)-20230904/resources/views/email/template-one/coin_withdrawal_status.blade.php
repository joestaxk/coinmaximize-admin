@include('email.template-one.header')
<p>Hi {{$name}},</p>
<p>
<p>
    {{$details}}
</p>
@include('email.template-one.footer')