@include('email.template-one.header')
<p>
    Your {{allSetting()['app_title']}}  Email Setup Is Working fine :)
</p>
@include('email.template-one.footer')


