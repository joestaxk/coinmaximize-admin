<!-- Start email footer area -->
<table border="0" cellpadding="0" cellspacing="0" style="width:100%;padding:15px 35px; background-color:#0E0E26;">
    <tr>
        <td align="center" valign="top">
            <table>
                <tr>
                    <td valign="center" align="center">
                        <p style="color: #F9B507">
                            {{__('Thanks a lot for being with us.')}} <br/>
                            <a style="color: #F9B507" href="{{settings('exchange_url')}}">{{allSetting()['app_title']}}</a>
                        </p>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

</td>
</tr>
</table>

</body>
</html>
