@include('email.header_new')
<p>
    Your {{allSetting()['app_title']}}  Email Setup Is Working fine :)
</p>
@include('email.footer_new')


